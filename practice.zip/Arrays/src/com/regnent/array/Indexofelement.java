package com.regnent.array;

import java.util.Scanner;

public class Indexofelement {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a  size array");
		int size = sc.nextInt();
		int array[] = new int[size];

		System.out.println("enter elements in array");
		for (int i = 0; i < array.length; i++) {
			array[i] = sc.nextInt();
		}

		System.out.println("enter a element");
		int num = sc.nextInt();
		sc.close();
		for (int i = 0; i < array.length; i++) {
			if (array[i] == num) {
				System.out.println(i);
				break;
			}
		}

	}

}
