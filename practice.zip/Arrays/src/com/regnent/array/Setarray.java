package com.regnent.array;

import java.util.*;

public class Setarray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a size of an array");
		int n = sc.nextInt();
		int array[] = new int[n];
		int temp = 0;
		System.out.println("enter a element in array");
		loop: for (int i = 0; i < array.length; i++) {

			temp = sc.nextInt();
			for (int j = 0; j <= i; j++) {
				if (temp == array[j]) {
					System.out.println("element is already there");
					i--;
					continue loop;
				}

			}
			array[i] = temp;

		}
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}

	}

}
