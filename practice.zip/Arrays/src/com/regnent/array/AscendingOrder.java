package com.regnent.array;
import java.util.Scanner;
public class AscendingOrder {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter size of array");
		int n=sc.nextInt();
		int  nonsortarray[]=new int[n];
		int sortedarray[]=new int[n];
		int temp=0;
		for (int i = 0; i < nonsortarray.length; i++) {
			nonsortarray[i]=sc.nextInt();
		}
		sc.close();
		for (int i = 0; i < n; i++) 
        {
            for (int j = i + 1; j < n; j++) 
            {
                if (nonsortarray[i] > nonsortarray[j]) 
                {
                    temp = nonsortarray[i];
                    nonsortarray[i] = nonsortarray[j];
                    nonsortarray[j] = temp;
                    sortedarray=nonsortarray;
                }
            }
        }
		for (int i = 0; i < sortedarray.length; i++) {
			System.out.print("asending order of array:"+sortedarray[i]);
		}
	
	}

}
