package com.regnent.array;

import java.util.Scanner;

public class Copyelements {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] array = new int[5];
		int[] array1 = new int[5];
		System.out.println("enter elements in the array");
		for (int i = 0; i < array.length; i++) {
			array[i] = sc.nextInt();
		}
		sc.close();
		array1 = array;
		for (int s : array1) {
			System.out.print(s);
		}

	}

}
