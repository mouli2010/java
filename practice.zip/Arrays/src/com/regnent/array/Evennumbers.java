package com.regnent.array;

import java.util.Scanner;

public class Evennumbers {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a  size array");
		int size = sc.nextInt();
		int array[] = new int[size];
		System.out.println("enter elements in array");
		for (int i = 0; i < array.length; i = i++) {
			array[i] = sc.nextInt();
			if (array[i] % 2 == 0) {
				System.out.println(array[i] + " ");
			}
		}
		sc.close();
	}
}
