package com.regnent.array;

import java.util.*;

public class DupicateInArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] array = new int[6];
		System.out.println("enter elements in the array");
		for (int i = 0; i < array.length; i++) {
			array[i] = sc.nextInt();
		}
		int count = 0;
		for (int j = 0; j < array.length; j++) {
			for (int k = j + 1; k < array.length; k++) {
				if (array[j] == array[k]) {
					count++;
				}
			}
			if (count == 1) {
				System.out.println(array[j]);
			}
			count = 0;

		}

	}
}
