package com.regnent.array;

import java.util.Arrays;
import java.util.Scanner;

public class Countofduplicateelements {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter array size: ");
		int size = input.nextInt();
		int[] array = new int[size];
		System.out.println("Enter array elements: ");
		for (int i = 0; i < array.length; i++) {
			array[i] = input.nextInt();
		}
		int count = 1;
		Arrays.sort(array);
		for (int i = 0; i < array.length; i++) {

			for (int j = i + 1; j < array.length; j++) {
				if (array[i] == array[j]) {
					count++;
				}
			}
			if (count > 1) {
				System.out.println();
				System.out.println("repeated element in array " + array[i] + ": " + count + " times");
				// i = i + count - 1;
			}
			count = 1;
		}

	}

}
