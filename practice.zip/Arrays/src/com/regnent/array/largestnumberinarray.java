package com.regnent.array;

import java.util.Scanner;

public class largestnumberinarray {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter array size: ");
		int size = input.nextInt();
		int[] array = new int[size];
		System.out.println("Enter array elements: ");
		for (int i = 0; i < array.length; i++) {
			array[i] = input.nextInt();
		}
		int max = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] > max) {
				max = array[i];
			}
		}
		System.out.println("Maximum number is : " + max);

	}

}
