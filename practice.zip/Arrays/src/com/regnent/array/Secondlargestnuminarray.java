package com.regnent.array;

public class Secondlargestnuminarray {

	public static void main(String[] args)
	{
		int array[]={10,90,30,89,54,23,45};
		int largestnumber=array[0];
		int secondlargenumber=array[1];
		for (int i = 0; i < array.length; i++) 
		{
			if(array[i]>largestnumber)
			{
				secondlargenumber=largestnumber;
				largestnumber=array[i];
			}
			else if(array[i]>secondlargenumber)
			{
				secondlargenumber=array[i];
			}
			
		}
		System.out.println("largest number in array:"+largestnumber);
		System.out.println("second largest number in array:"+secondlargenumber);

	}

}
