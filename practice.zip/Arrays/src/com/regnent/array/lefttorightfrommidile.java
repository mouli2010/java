package com.regnent.array;

import java.util.Scanner;

public class lefttorightfrommidile {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a  size array");
		int size = sc.nextInt();
		int array[] = new int[size];
		System.out.println("enter elements in array");
		for (int i = 0; i < array.length; i++) {
			array[i] = sc.nextInt();
		}
		sc.close();
		for (int i = array.length / 2; i < array.length; i++) {
			System.out.println(array[i]);

		}

	}
}
