package com.regnent.array;

public class Sumandaverage {

	public static void main(String[] args) {
		int array []={1,2,3,4,5,6};
		int sum=0,average; 
		for (int i = 1; i < array.length; i++)
		{
			sum=sum+array[i];
		}
        average=sum/array.length;
		System.out.println("array elements sum:"+sum);
		System.out.println("array elements average:"+average);
	}

}
