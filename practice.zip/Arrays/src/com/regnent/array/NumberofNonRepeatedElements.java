package com.regnent.array;

import java.util.Scanner;

public class NumberofNonRepeatedElements {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] array = new int[6];
		System.out.println("enter elements in the array");
		for (int i = 0; i < array.length; i++) {
			array[i] = sc.nextInt();
		}
		int count = 0;
		int flag = 0;
		for (int j = 0; j < array.length; j++) {
			for (int k = 0; k < array.length; k++) {
				if (j != k) {
					if (array[j] != array[k]) {
						flag = 1;
					} else {
						flag = 0;
						break;
					}
				}
			}

			if (flag == 1) {
				count++;
				System.out.print(array[j]);
			}

		}
		System.out.println();
		System.out.println("no of non repeated characters:" + count);

	}

}
