package com.regnent.array;

public class Printarray {

	public static void main(String[] args) {
		int array[] = { 1, 2, 3, 4, 5, 6 };
		int array1[]=new int[6];
		/*
		 * for (int i = 0; i < array.length; i++) { System.out.print(array[i]+
		 * " ");
		 * 
		 * }
		 */
		array1=array;
		for (int arr : array) {
			System.out.print(arr + " ");
		}

	}

}
