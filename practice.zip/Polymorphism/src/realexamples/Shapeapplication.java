package realexamples;
interface Shape
{
	public void draw();

}
class Rectangle implements Shape
{
	public void draw()
	{
		System.out.println("rectangle is drawn");
	}
}
class Circle  implements Shape
{
	public void draw()
	{
		System.out.println("circle is drawn");
	}
}
class Generateshapeobjects
{
	static Shape getobject(String shape)
	{
		if(shape=="Rectangle")
		{
			return new Rectangle();
		}
		else
		{
			return new Circle();
		}
	}
}
public class Shapeapplication {

	public static void main(String[] args) {
		String shape="";
		Shape sh=Generateshapeobjects.getobject("Rectangle");
		sh.draw();

	}

}
