package realexamples;

interface Person {
	
	public void sayHello();
	
}
class M implements  Person
{
	String fileName="MALE";
	public void sayHello()
	{
		Iplayer Ip=new vlcplayer();
		Ip.play(fileName);
	}
}
class F implements  Person
{
	String fileName="FEMALE";
	public void sayHello()
	{
		Iplayer Ip=new vlcplayer();
		Ip.play(fileName);
	}
}
public class Application {

	public static void main(String[] args) {
		Person p=null;
		String gender="M";
		if(gender=="M")
		{
			p=new M();
		}
			else
			{
				p=new F();
			}
		
p.sayHello();
	}

}
