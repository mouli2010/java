package realexamples;

public class Human {
	String gender;
	public void sayHi()
	{
		System.out.println("say hii");
	}
}
class Male extends Human
{
	String fileName="ROBO";
	public void sayHi()
	{
		Iplayer Ip=new vlcplayer();
		Ip.play(fileName);
	}
}
class FeMale extends Human
{
	//String fileName="ROBO 2.O";
	public void sayHi()
	{
		Iplayer Ip=new vlcplayer();
		Ip.play("ROBO 2.O");
	}
}