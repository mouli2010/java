package realexamples;

public class App {

	public static void main(String[] args) {
		Human h=null;
		String gender="Male";
		if(gender=="Male")
		{
			h=new Male();
		}
			else
			{
				h=new FeMale();
			}
		
h.sayHi();
	}

}
