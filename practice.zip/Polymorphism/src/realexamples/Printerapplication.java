package realexamples;
import java.util.*;
interface Printer
{
	public void getReader();
	public void print();
} 
abstract class Fiereader 
{
	public void openfile()
	{
		System.out.println("file is opened");
	}
	public void closefile()
	{
		System.out.println("file is closed");
	}
	
	
}
class Textformat extends Fiereader implements Printer{
	public void getReader()
	{
		openfile();
		System.out.println("read the data");
		closefile();
	}
	public void print(){
		openfile();
		System.out.println("print the data in text format");
		closefile();
		
	}
}
class Pdfformat extends Fiereader implements Printer{
	public void getReader()
	{
		openfile();
		System.out.println("read the data");
		closefile();
	}
	public void print(){
		openfile();
		System.out.println("print the data in pdf format");
		closefile();
		
	}
}
class Xlsformat extends Fiereader implements Printer{
	public void getReader()
	{
		openfile();
		System.out.println("read the data");
		closefile();
	}
	public void print(){
		openfile();
		System.out.println("print the data in xls format");
		closefile();
		
	}
}
class Generateprinterobjects
{
	static Printer getobject(String format)
	{
		if(format.equalsIgnoreCase("Pdfformat"))
		{
			return new Pdfformat();
		}
		else if(format.equalsIgnoreCase("Textformat"))
		{
			return new Textformat();
		}
		else 
		{
			return new Xlsformat();
		}
	}
}


public class Printerapplication {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a type of a file");
		String inputtype=sc.nextLine();
		sc.close();
		
		String format="";
		Printer pri=Generateprinterobjects.getobject(inputtype);
		pri.getReader();
		pri.print();

	}

}
