package realexamples;
interface Itransaction
{
	 public void withdrawal(String accno,int atmpin,int amount)throws Exception;
}
class SBI implements Itransaction
{

	@Override
	public void withdrawal(String accno, int atmpin, int amount)throws Exception {
	try{
		System.out.println("collect your amount");
	}
	catch(Exception e)
	{
		System.out.println("recover the problem");
		throw new Exception("your amount will be recoverd");
	}
		
	}
	
}
public class Bankwithdrawal {

	public static void main(String[] args)throws Exception {
		
		Itransaction trans=new SBI();
		trans.withdrawal("125469745615",9999,10000 );

	}

}
