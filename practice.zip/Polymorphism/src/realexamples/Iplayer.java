package realexamples;

public interface Iplayer {
	void play  (String fileName);

}
class vlcplayer implements Iplayer
{
	public void play  (String fileName)
	{
		System.out.println("vlc media player file is \n"+fileName);
	}
}
class windowsplayer implements Iplayer
{
	public void play  (String fileName)
	{
		System.out.println("windows media player file is"  +fileName);
	}
}
