package genric;

public class StackdownflowException extends Exception {
	public StackdownflowException(String msg)
	{
	System.out.println(msg);
	}

}
