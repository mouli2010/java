package genric;

public class GenericexStack {

	public static void main(String[] args)throws Exception {
		/*Stack<Integer>st=new Stack<Integer>();
		st.push(23);
		st.push(25);
		st.push(54);
		st.push(30);
		st.push(45);
		//Integer i1=st.pop();*/
		Stack<String>st=new Stack<String>();
		st.push("raja");
		st.push("mouli");
		st.push("ravi");
		st.push("hemant");
		st.push("mahit");
		String s1=st.pop();
		//Integer i1=st.pop();
		st.show();
		


	}

}
