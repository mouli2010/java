package genric;

public class Student {
	public int id;
	public String name;
	public  int getid()
	{
		return this.id;
	}
	@Override
	public String toString() {
		return this.id+"   "+this.name;
	}
	boolean equals(Student obj)
	{
		return this.id==obj.id;
	}
	

}
