package genric;

public class StackoverflowException extends Exception {
	public StackoverflowException(String msg )
	 {
		System.out.println(msg);
	 }

}
