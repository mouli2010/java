package genric;

public class Stack<E> {
	int cursor=0;
	Object arr[]=new Object[5];
	public void push(E obj)throws StackoverflowException
	{
		if(cursor==arr.length)
		{
			throw new StackoverflowException("Stack Overflow !");  
		}
		else
		{
		arr[cursor]=obj;
		cursor++;
		}
		 
	}
	
public  E pop() throws StackdownflowException 
{
	if(cursor==0)
	{
		throw new StackdownflowException("Stack Underflow !"); 
	}
	else
	{
		cursor--;
		Object ob=arr[cursor];
	
	arr[cursor]=null;
	E e=(E)ob;
return e;
	}
}
public void show()
{
	for(Object s:arr)
	{
		System.out.println(s);
	}
}
}