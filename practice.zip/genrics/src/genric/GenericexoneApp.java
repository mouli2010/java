package genric;

public class GenericexoneApp {

	public static void main(String[] args) {
		Student sd=new Student();
		sd.id=4;
		sd.name="ravi";
		//System.out.println(sd);
		Student sd1=new Student();
		sd1.id=4;
		sd1.name="raju";
		boolean iseq=sd.equals(sd1);
		System.out.println(iseq);
		System.out.println(sd.toString());
		Object ob=new Student();
		String st=(String)ob;	//hear no compilation error because string is already there in object class
		boolean ise=st.equals(sd1);
		System.out.println(ise);
		/*Exception in thread "main" java.lang.ClassCastException: genric.Student cannot be cast to java.lang.String
		at genric.GenericexoneApp.main(GenericexoneApp.java:16)*/
		//int data=st.getid();//Unresolved compilation problem: The method getid() is undefined for the type String

	

	}

}
