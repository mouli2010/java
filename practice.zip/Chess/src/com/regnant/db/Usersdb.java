package com.regnant.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Usersdb {
	public void addUser(String fname, String lname, String email, String mobile) throws ClassNotFoundException, SQLException {

		Class.forName("org.postgresql.Driver");
		Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/rajamouli", "postgres", "mouli123");
		PreparedStatement pst = conn.prepareStatement("INSERT INTO tournament.participants (fname, lname, email, mobile) VALUES (?,?,?,?);"); 
		System.out.println(fname+lname+email+mobile);
		pst.setString(1, fname);
		pst.setString(2, lname);
		pst.setString(3,email);
		pst.setString(4, mobile);
		pst.executeUpdate();
		}


}
