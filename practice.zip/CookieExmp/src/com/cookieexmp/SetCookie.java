package com.cookieexmp;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SetCookie
 */
@WebServlet("/SetCookie")
public class SetCookie extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SetCookie() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		Cookie c1=new Cookie("ANDHRA","HYDERABAD");
		Cookie c2 = new Cookie("TAMILNADU", "CHENNAI");
       response.addCookie(c1);
       response.addCookie(c2);
       Cookie c3 = new Cookie("KARNATAKA", "BANGLORE");
       Cookie c4 = new Cookie("BIHAR", "PATNA");
       c3.setMaxAge(300);
       c4.setMaxAge(420);
       response.addCookie(c3);
       response.addCookie(c4);
       System.out.println("SUCCESSFUL IN SETTING COOKIES");
       RequestDispatcher rd = request.getRequestDispatcher("ShowCookie");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
