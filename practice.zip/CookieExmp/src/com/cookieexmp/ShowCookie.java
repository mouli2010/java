package com.cookieexmp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ShowCookie
 */
@WebServlet("/ShowCookie")
public class ShowCookie extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowCookie() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String title=" Active Cookies";
		pw.println("<html><head><title>"+title+"</title></head><body>");
		pw.println("<table border=\"1\" align=\"center\">");
		pw.println("<tr><th>Cookie Name</th><th>Cookie Value</th></tr>");
		Cookie ck[]=request.getCookies();
		if(ck!=null)
		{
			for(int i=0; i<ck.length;i++)
			{
				pw.println("<tr><td>"+ck[i].getName()+"</td><td>"+ck[i].getValue()+"</td></tr>");
				
			}
		}
		else {
            System.out.println("NO COOKIES PRESENT");

		}
		pw.println("</table></body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
