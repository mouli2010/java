package string;

import java.util.Scanner;

public class Stringpalindrom {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	     System.out.println("enter the string");
	     String string=sc.nextLine();
	     sc.close();
	     StringBuffer sb=new StringBuffer(string);
	     String revstring=sb.reverse().toString();
	     if(string.equals(revstring))
	     {
	    	 System.out.println("given string is palindrom");
	     }
	     else 
	     {
	    	 System.out.println("given string is not  palindrom");
	     }

	}


	}


