package string;

public class Intigertostring {

	public static void main(String[] args) {
	int num=255;
	String str1=Integer.toString(num);
	String str2=String.valueOf(num);
	String str3=Integer.toBinaryString(num);
	String str4=Integer.toOctalString(num);
	String str5=Integer.toHexString(num);
	System.out.println(str1);
	System.out.println(str2);
	System.out.println(str3);
	System.out.println(str4);
	System.out.println(str5);

	}

}
