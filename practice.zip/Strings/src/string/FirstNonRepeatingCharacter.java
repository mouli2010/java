package string;

import java.util.Scanner;

public class FirstNonRepeatingCharacter 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String string=sc.nextLine();
		char[] charArr = string.toCharArray();

        for (int i = 0; charArr.length > i; i++) {
            int count = 0;
            for (int j = 0; charArr.length > j; j++) 
            {
                if (charArr[i] == charArr[j]) 
                {
                    count++;
                }
            }
            if (count == 1){
                System.out.println("First Non Repeating Character is: " + charArr[i]);
                break;
            }
        }


	}

}
