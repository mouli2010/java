package string;
import java.util.Scanner;
public class Countwords {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a string");
		String string=sc.nextLine();
		sc.close();
		String words []=string.split(" ");
		int count=words.length;
		System.out.println("number of words in a string is:"+count);
		

	}

}
