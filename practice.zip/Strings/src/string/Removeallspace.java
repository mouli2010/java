package string;

import java.util.Scanner;

public class Removeallspace {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a string");
		String str=sc.nextLine();
		//sc.close();
		String noSpaceString=str.replaceAll("\\s", "");
		System.out.println(noSpaceString);

	}

}
