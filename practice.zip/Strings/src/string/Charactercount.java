package string;
import java.util.*;
public class Charactercount {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a string");
		String str=sc.nextLine();
		System.out.println("enter a character you want to search ");
		String c=sc.nextLine();
		String str1=str.replace(c, "");
		System.out.println("character count of given char is : "+(str.length()-str1.length()));
		//System.out.println(str.length());
		//System.out.println(str1.length());
		

	}

}
