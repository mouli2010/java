package string;
import java.util.*;
public class Countvowelconsonents {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a string");
		String string=sc.nextLine();
		int lenth=string.length();
		char vowels[]=new char[lenth];
		char consonents[]=new char[lenth];
		int vowelcount=0,consonentcount=0;
		for (int index = 0; index < string.length(); index++)
		{
			if(string.charAt(index)=='a'||string.charAt(index)=='e'||string.charAt(index)=='i'||string.charAt(index)=='o'||string.charAt(index)=='u')
			{
				vowels[index]=string.charAt(index);
				vowelcount++;
			}
		}
		System.out.println("number of vowels  is:");
		for (int index = 0; index < vowels.length; index++) 
		{
			System.out.print(vowels[index]);
			
		}
		System.out.println("vowels count:"+vowelcount);
		for (int index = 0; index < string.length(); index++)
		{
			if(!(string.charAt(index)=='a'||string.charAt(index)=='e'||string.charAt(index)=='i'||string.charAt(index)=='o'||string.charAt(index)=='u'))
			{
				consonents[index]=string.charAt(index);
				consonentcount++;
			}
		}
		System.out.println("number of consonents  is:");
		for (int index = 0; index < consonents.length; index++) 
		{
			System.out.print(consonents[index]);
			
		}
		System.out.println("consonents count:"+consonentcount);

	}

}
