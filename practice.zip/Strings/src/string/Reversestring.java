package string;

import java.util.Scanner;

public class Reversestring {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the string");
		String inputstring = sc.nextLine();
		sc.close();
		String outputstring;
		StringBuffer sb=new StringBuffer(inputstring);
		outputstring=sb.reverse().toString();
		System.out.println(outputstring);

	}

}
