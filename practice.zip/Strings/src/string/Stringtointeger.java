package string;

public class Stringtointeger {

	public static void main(String[] args) {
		String str="2010";
		int num1=Integer.parseInt(str);
		int num2=Integer.valueOf(str);
		System.out.println(num1);
		System.out.println(num2);

	}

}
