package string;

import java.util.Scanner;

public class Duplicatewords {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        System.out.print("Enter the string:");
        String str=sc.nextLine();
		 String str1 []=str.split(" ");
		 int count = 1;
		 for (int i = 0;i<str1.length; i++) {
	            for (int j =i+1;j<str1.length; j++) 
	            {
	                if (str1[i].equals(str1[j])) 
	                {
	                    count++;
	                    str1[j]="0";
	                }
	               
	            }
	            if(str1[i]!="0"&&count>1)
	            {
	            	System.out.println(str1[i]+" "+count);
	            }
	            count=1;
	        }
		 
	}

}
