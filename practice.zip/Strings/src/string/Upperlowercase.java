package string;

import java.util.Scanner;

public class Upperlowercase {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the string");
		String uppercasestring = sc.nextLine().toUpperCase();
		String lowercasestring = uppercasestring.toLowerCase();
        sc.close();
		System.out.println("strng print in uppercase:"+uppercasestring);
		System.out.println("string print in lowercase:"+lowercasestring);

	}

}
