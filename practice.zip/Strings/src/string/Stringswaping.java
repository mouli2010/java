package string;

import java.util.Scanner;

public class Stringswaping {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the first string");
		String firststring = sc.nextLine();
		System.out.println("enter the second string");
		String secondstring = sc.nextLine();
		String temporarystring;
		temporarystring=firststring;
		firststring=secondstring;
		secondstring=temporarystring;
		System.out.println("swapping of two strings:\n"+firststring+"\n"+secondstring);
		
	}

}
