package multithread;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;

public class ProducerAndConsumer2222 {

public static void main(String[] args) {
//TODO Auto-generated method stub
Processor1 processor = new Processor1();
Thread t1 = new Thread(new Runnable() {
Random r = new Random();
@Override
public void run() {
try {
for(int i=0; i< 100; i++) {
processor.add(i);
System.out.println("Adding :         " +i );
}
} catch (InterruptedException e) {
e.printStackTrace();
}
}

});
Thread t2 = new Thread(new Runnable() {

@Override
public void run() {
while(true) {
try {
int data = processor.remove();
System.out.println("Removed :         " +data );
} catch (InterruptedException e) {
e.printStackTrace();
}
}
}

});

t1.start();
t2.start();

}

}

class Processor1 {

private BlockingQueue<Integer> list = new ArrayBlockingQueue<>(5);
     

public void add(int data) throws InterruptedException {
synchronized (list) {
if (list.size() >= 5) {
System.out.println("Waiting for removing items from the list...");
list.wait();
}
System.out.println("Adding data: " + data);
list.add(data);
list.notifyAll();
//Thread.sleep(1000);
}
//list.put(data);
}

public int remove() throws InterruptedException {

synchronized (list) {
int data;

if (list.size() == 0) {
list.wait();
System.out.println("Waiting for adding items to the list...");
} 
data = list.remove();
list.notifyAll();
//Thread.sleep(1000);

return data;
}

//return list.take();
}
}


