package multithread;

import java.util.Random;

class Buffer1{
	private int data;
	private boolean status;
	public Buffer1() {
		this.status=true;
	}
	public synchronized void produce1(int newdata) {
		while(!this.status)
		{ 
			try {
				this.wait();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		this.data=newdata;
		this.status=false;
		this.notify();
		System.out.println("Produced:" + newdata);
	}
	public synchronized int consume1() {
	    while (this.status) {
	      try {
	        this.wait();
	      } catch (InterruptedException e) {
	        e.printStackTrace();
	      }
	    }
	    this.status = true;
	    this.notify();
	    System.out.println("Consumed:" + data);
	    return data;
	  }
}
class Producer1 extends Thread {
	  private Buffer1 buffer1;

	  public Producer1(Buffer1 buffer) {
	    this.buffer1 = buffer;
	  }

	  public void run() {
	    Random rand = new Random();
	    while (true) {
	      int n = rand.nextInt();
	      buffer1.produce1(n);
	    }
	  }
	}
class Consumer1 extends Thread
{
	private Buffer1 buffer1;
	private int i =0;
	  public Consumer1(Buffer1 buffer) {
	    this.buffer1 = buffer;
	  }

	  public void run() {
	    int data;
	    while (true) { 
	      data = buffer1.consume1();
	      i++;
	      if(i==100)
	    	  System.exit(0);
	    }
	  }
}
public class ProducerconsumerApptest {

	public static void main(String[] args) {
		Buffer1 buffer1 = new Buffer1();
	    Producer1 p = new Producer1(buffer1);
	    Consumer1 c = new Consumer1(buffer1);

	    p.start();
	    c.start();

	}

}
