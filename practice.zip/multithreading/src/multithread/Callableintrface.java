package multithread;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class Factorial implements Callable<Integer> 

{
	int num;
	public Factorial( int num)
	{
		this.num=num;
	}
	public Integer call() throws Exception
	{
		 int n=5, fact=1;
		 for (int i = 1; i <=5; i++) {
			 fact=fact*i;
			
		}
		 return fact;
	}
	
}
public class Callableintrface {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
	ExecutorService ser=Executors.newSingleThreadExecutor();
	
	Future<Integer>res5=ser.submit(new Factorial(5) );
	Integer f1=res5.get();
	System.out.println("factorial of 5 :"+f1);
	

	}

}
