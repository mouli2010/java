package multithread;

//import javax.swing.plaf.synth.SynthSpinnerUI;

public class Accountholder implements  Runnable {
	private Account account;
	public Accountholder(Account account) {
		this.account=account;
	}
	public void run() {
		for (int i = 1; i <=2; i++) {
			makewithdrawal(2000);
			if(account.getbalance()<0)
			{
				System.out.println("amount is overdrawn");
			}
			
		}
		
	}
	private   synchronized void makewithdrawal(int withdrawamount) {
		if(account.getbalance()>=withdrawamount) {
			System.out.println(Thread.currentThread().getName()+"is going to withdraw"+withdrawamount);
			try {
				Thread.sleep(3000);
				
			}catch(InterruptedException ex) {
				
			}
			account.withdraw(withdrawamount);
			System.out.println(Thread.currentThread().getName()+"complets the  withdrawal of"+withdrawamount);
			
		}else
		{
			System.out.println("not enough in account for"+Thread.currentThread().getName()+"to withdraw"+account.getbalance());
			
		}
	}
} 
