package multithread;

import java.util.Random;

class Buffer {
	
private int x=0;
public boolean status = false;
protected int getX() {
	return x;
}
protected void setX(int x) {
	this.x = x;
}
}
class Producer implements Runnable
{
	Buffer b;
	Producer(Buffer b)
	{
		this.b=b;
	}
	Random random = new Random();
	public void run() {
		for (int i = 1; i <=100; i++) 
		{
			int j = random.nextInt();
			try {
				 synchronized (this) {
				wait();
				this.b.setX(j);
				
				notify();
				 }
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		
		}
		
	}
	
}
class Consumer implements Runnable
{
	Buffer b;
	Consumer(Buffer b)
	{
		this.b=b;
	}
	public void run() {
		try {
			 synchronized (this) {
			wait();
			System.out.println("hi");
			System.out.println(this.b.getX());
			notify();
			 }
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
		
	}
}
public class ProducerConsumerExample {

	public static void main(String[] args)throws InterruptedException {
		Buffer buffer = new Buffer();
		Producer pro=new Producer(buffer);
		Consumer con=new Consumer(buffer);
		Thread producerThread = new Thread(pro);
		Thread consumerThread = new Thread(con);
		 producerThread.start();
	        consumerThread.start();

	}

}
