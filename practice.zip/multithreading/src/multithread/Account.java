package multithread;

public class Account {
	private int balance=6000;
	public int getbalance() {
		return balance;
	}
	public void withdraw(int amount)
	{
		balance=balance-amount;
	}

}
