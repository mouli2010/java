package multithread;

public class Accounttestapp {

	public static void main(String[] args) {
		Account acc=new Account();
		Accountholder acholder=new Accountholder(acc);
		Thread t1=new Thread(acholder);
		Thread t2=new Thread(acholder);
		t1.setName("raja");
		t2.setName("mouli");
		t1.start();
		t2.start();

	}

}
