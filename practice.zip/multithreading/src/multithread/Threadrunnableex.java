package multithread;
class Hii implements Runnable
{
	public void run()
	{
	for(int i=1;i<=5;i++)
	{
		System.out.println("hii");
		try{Thread.sleep(500);
			}
		catch(Exception e) {
	}
	}
	}
}
class Helllo implements Runnable
{
	public void run()
	{
		for (int i = 1; i <=5; i++) 
		{
			System.out.println("helllo");
			try{
				Thread.sleep(500);
				}
			catch(Exception e) {
		                       }
		
	        }
	}
	}

public class Threadrunnableex {

	public static void main(String[] args) {
		Hii obj1=new Hii();
		Helllo obj2=new Helllo();
		Thread t1=new Thread(obj1);
		Thread t2=new Thread(obj2);
		t1.start();
		try{
			Thread.sleep(50);
			}
		catch(Exception e) {
	                       }
		
		t2.start();

	

	}

}
