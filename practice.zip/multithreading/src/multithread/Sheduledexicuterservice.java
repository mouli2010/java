package multithread;

public class Sheduledexicuterservice {

	public static void main(String[] args) {
		

	}

}
