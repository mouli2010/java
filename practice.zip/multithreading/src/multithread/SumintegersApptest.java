package multithread;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class Numbers
{
List<Integer> list = new ArrayList<Integer>();
List<Integer>sharedlist=new ArrayList<Integer>();

public void load() 
  {
for (int i = 0; i < 100000; i++) 
{
list.add(i);
  }
    }
}


class Sumnumbers implements Callable<Integer> {
List<Integer> list;
List<Integer>sharedlist;
int startindex;
int endindex;
Lock l;

Sumnumbers(List<Integer> list, int start, int end,List<Integer>sharedlist,Lock l) {
this.list = list;
this.startindex = start;
this.endindex = end;
this.sharedlist=sharedlist;
this.l=l;

}

@Override
public Integer call() throws Exception {
int sum = 0;

for (int i = startindex; i < endindex; i++) {
    sum=sum+list.get(i);
    //synchronized (this) {
		try {
			l.lock();
		//Semaphore s=new Semaphore(3);
	sharedlist.add(i);
	l.unlock();
		}
		catch (Exception e) {
		l.unlock();
		}
     //}
	
}


return sum;
}
}
public class SumintegersApptest {

	public static void main(String[] args)throws InterruptedException, ExecutionException {
		long startTime = System.nanoTime();
		Numbers obj=new Numbers();
		obj.load();
		Lock l=new ReentrantLock();
		ExecutorService es=Executors.newFixedThreadPool(2);
		Future<Integer> f1=es.submit(new Sumnumbers(obj.list, 0, 10000,obj.sharedlist,l));
		Future<Integer> f2=es.submit(new Sumnumbers(obj.list, 10000, 20000,obj.sharedlist,l));
		Future<Integer> f3=es.submit(new Sumnumbers(obj.list, 20000, 30000,obj.sharedlist,l));
		Future<Integer> f4=es.submit(new Sumnumbers(obj.list, 30000, 40000,obj.sharedlist,l));
		Future<Integer> f5=es.submit(new Sumnumbers(obj.list, 40000, 50000,obj.sharedlist,l));
		Future<Integer> f6=es.submit(new Sumnumbers(obj.list, 50000, 60000,obj.sharedlist,l));
		Future<Integer> f7=es.submit(new Sumnumbers(obj.list, 60000, 70000,obj.sharedlist,l));
		Future<Integer> f8=es.submit(new Sumnumbers(obj.list, 70000, 80000,obj.sharedlist,l));
		Future<Integer> f9=es.submit(new Sumnumbers(obj.list, 80000, 90000,obj.sharedlist,l));
		Future<Integer> f10=es.submit(new Sumnumbers(obj.list, 90000, 100000,obj.sharedlist,l));
		Integer s1=f1.get();
		Integer s2=f2.get();
		Integer s3=f3.get();
		Integer s4=f4.get();
		Integer s5=f5.get();
		Integer s6=f6.get();
		Integer s7=f7.get();
		Integer s8=f8.get();
		Integer s9=f9.get();
		Integer s10=f10.get();
        System.out.println("total sum");
		System.out.println(s1+s2+s3+s4+s5+s6+s7+s8+s9+s10);
		long endTime     = System.nanoTime();
		long totalTime = endTime - startTime;
		System.out.println("time:"+totalTime);
		System.out.println(Runtime.getRuntime().availableProcessors());

	}

}
