package multithread;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
class Producer2 implements Runnable
{
	List<Integer>lis;
	int maxsize;
	 Producer2(List<Integer> l, int size)
	{
		this.lis=l;
		this.maxsize=size;
	}
	 public void run() {
		 
		 while (true) {
	            while(lis.size() == maxsize) {
	                System.out.println("Waiting to add");
	                synchronized (this) {
	                    try {
							lis.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
	                }
	            }
	           
	                int value = new Random().nextInt(10);
	                lis.add(value);
	                System.out.println("Added to list: " + value);
	                lis.notify();
	        }
	 }
}
class Consumer2 implements Runnable
{
	List<Integer>lis;
	int maxsize;
	Consumer2(List<Integer> l, int size)
	{
		this.lis=l;
		this.maxsize=size;
	}
	 public void run() {
		 
		 while (true) {
	            while (lis.isEmpty()) {
	                System.out.println("Waiting to remove");
	                synchronized (this) {
	                    try {
							lis.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
	                }
	            }
	           int i=0;
				
	                int num = lis.remove(i);
	           		i++;
	                System.out.println("remove to list: " + num);
	           
	                lis.notify();
	           
	        }
	 }
}
public class Producerconsumer {

	public static void main(String[] args) 
	{
		List<Integer>lis=new  ArrayList<Integer>();
		Thread pro=new Thread(new Producer2( lis,5));
		Thread con=new Thread(new Consumer2( lis,5));
		synchronized (lis) {
			
		pro.start();
		con.start();
		}
		

	}

}
