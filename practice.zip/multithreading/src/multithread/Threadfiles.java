package multithread;

import java.io.FileReader;

class Story1 extends Thread
{
	public void run()
	{
		try{
			FileReader fr=new FileReader("e:\\mouli.txt");
			int i=0;
			while((i=fr.read())!=-1)
			{
				System.out.print((char)i);
			}
			Thread.sleep(1500);
			fr.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
class Story2 extends Thread
{
	public void run() {
		try{
			FileReader fr=new FileReader("e:\\rajamouli.txt");
			int i=0;
			while((i=fr.read())!=-1)
			{
				System.out.print((char)i);
			}
			Thread.sleep(500);
			fr.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
public class Threadfiles {

	public static void main(String[] args) {
		Story1 st1=new Story1();
		Story2 st2=new Story2();
		st1.start();
		st2.start();
	

	}

}
