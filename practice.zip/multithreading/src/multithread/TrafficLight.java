package multithread;
class TurnRed implements Runnable

{

 public void run()

  {

   synchronized(this) {

   try {
	   System.out.println("red");
	   Thread.sleep(1000);
	   } catch(InterruptedException e) {}

   notify(); 
   }

  }

}

class TurnYellow implements Runnable

{

 public void run()

  {

   synchronized(this) {

   try {
	   System.out.println("yellow");
	   Thread.sleep(1000); } catch(InterruptedException e) {}

   notify();
   }

  }

}

class TurnGreen implements Runnable

{

 public void run()

  {

   synchronized(this) {

   try {
	   System.out.println("green");
	   Thread.sleep(1000); } catch(InterruptedException e) {}

   notify(); }

  }

}
 class Signals implements Runnable {
	

		  public void run()

		   {

		    while(true)

		     {

		      Thread turnRed = new Thread(new TurnRed());

		      turnRed.start() ;

		      synchronized(turnRed)

		       {

		        try { turnRed.wait() ; } catch(InterruptedException e) {}

		       }

		      Thread turnYellow = new Thread(new TurnYellow());

		      turnYellow.start() ;

	      synchronized(turnYellow)

	       {

		        try { turnYellow.wait() ; } catch(InterruptedException e) {}

		       }

		      Thread turnGreen = new Thread(new TurnGreen());

		      turnGreen.start() ;

		      synchronized(turnGreen)

		       {

		        try { turnGreen.wait() ; } catch(InterruptedException e) {}

		       }

		     }

		   }

	}
public class TrafficLight
{
public static void main(String[] args) {
	Thread t1 = new Thread(new Signals());
	t1.start();
}
}
