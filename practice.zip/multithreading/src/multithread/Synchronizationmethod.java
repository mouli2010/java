package multithread;
class Table
{
	synchronized void printtable(int n)
	{
		for (int i = 1; i<=5; i++) {
			System.out.println(n*i);
		
		try{Thread.sleep(500);}
		catch (Exception e) {
			System.out.println(e);
		}
		}
	}
}
class Mythread1 extends Thread
{ 
	Table t;
	Mythread1(Table t)
	{
		this.t=t;
	}
	public  void run()
	{
		t.printtable(5);
	}
}
class Mythread2 extends Thread
{ 
	Table t;
	Mythread2(Table t)
	{
		this.t=t;
	}
	public  void run()
	{
		t.printtable(100);
	}
}

public class Synchronizationmethod {

	public static void main(String[] args) {
		Table tab=new Table();
		Mythread1 t1=new Mythread1(tab);
		Mythread2 t2=new Mythread2(tab);
		t1.start();
		t2.start();
		

	}

}
