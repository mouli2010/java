package multithread;
class Table2
{
	void printtable(int n)
	{
	synchronized (Table2.class) {
		for (int i = 1; i <=5; i++) {
			System.out.println(n*i);
			try {
				Thread.sleep(500);
			}
			catch (Exception e) {
				System.out.println(e);
			}
			
		}
		
	}
	}
}
class Mythread3 extends Thread
{ 
	Table2 t;
	Mythread3(Table2 t)
	{
		this.t=t;
	}
	public  void run()
	{
		t.printtable(5);
	}
}
class Mythread4 extends Thread
{ 
	Table2 t;
	Mythread4(Table2 t)
	{
		this.t=t;
	}
	public  void run()
	{
		t.printtable(100);
	}
}

public class Synchronizationblock {

	public static void main(String[] args) {
		Table2 tab=new Table2();
		Mythread3 t1=new Mythread3(tab);
		Mythread4 t2=new Mythread4(tab);
		t1.start();
		t2.start();

	}

}
