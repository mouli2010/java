package multithread;

public class Deadlockex {

	public static void main(String[] args) 
	{
	final String resource1="ratan";
	final String resource2="durga";
	Thread t1=new Thread() 
	{
		public void run()
		{
			synchronized (resource1)
			{
				System.out.println("thread1:locked resource1");
				try {
					Thread.sleep(500);
				
			        }
				catch (Exception e) {
		
				}
				synchronized (resource2) {
					System.out.println("thread1:locked resource2");
				}
					
				}
		}
	};
	Thread t2=new Thread() {
		public void run() {
			synchronized (resource2) {
				System.out.println("thread2:locked resource2");
				try {Thread.sleep(500);
				
			}
				catch (Exception e) {
		
				}
				synchronized (resource1) {
					System.out.println("thread2:locked resource");
				}
					
				}
		
	}
	

	};
	t1.start();  
    t2.start(); 
	}
	}

