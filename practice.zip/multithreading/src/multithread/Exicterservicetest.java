package multithread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

 class WorkerThread implements Runnable {
	   private int workerNumber;

	   WorkerThread(int workerNumber) {
	      this.workerNumber = workerNumber;
	   }

	   public void run() {
	      // The thread simply prints 1 to 5
	      for (int i = 1; i <= 5; ++i) {
	         System.out.printf("Worker %d: %d\n", workerNumber, i);
	         try {
	            // sleep for 0 to 0.5 second
	            Thread.sleep((int)(Math.random() * 500));
	         } catch (InterruptedException e) {}
	      }
	   }
	}

public class Exicterservicetest {

	public static void main(String[] args) {

	      ExecutorService es =  Executors.newFixedThreadPool(2);
	      WorkerThread[] workers = new WorkerThread[5];
	      for (int i = 0; i < 5; ++i) {
	         workers[i] = new WorkerThread(i+1);
	         es.execute(workers[i]);
	      }
	      es.shutdown();

	}

}
