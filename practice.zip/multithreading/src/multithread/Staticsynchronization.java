package multithread;
class Table3
{
	synchronized  static void printtable(int n)
	{
		for (int i = 1; i<=5; i++) {
			System.out.println(n*i);
		
		try{Thread.sleep(500);}
		catch (Exception e) {
			System.out.println(e);
		}
		}
	}
}
class Mythread5 extends Thread
{ 
	Table3 t;
	Mythread5(Table3 t)
	{
		this.t=t;
	}
	public  void run()
	{
		t.printtable(5);
	}
}
class Mythread6 extends Thread
{ 
	Table3 t;
	Mythread6(Table3 t)
	{
		this.t=t;
	}
	public  void run()
	{
		t.printtable(100);
	}
}
class Mythread7 extends Thread
{ 
	Table3 t;
	Mythread7(Table3 t)
	{
		this.t=t;
	}
	public  void run()
	{
		t.printtable(1000);
	}
}
public class Staticsynchronization {

	public static void main(String[] args) {
		Table3 tab=new Table3();
		Mythread5 t1=new Mythread5(tab);
		Mythread6 t2=new Mythread6(tab);
		Mythread7 t3=new Mythread7(tab);
		t1.start();
		t2.start();
		t3.start();

	}

}
