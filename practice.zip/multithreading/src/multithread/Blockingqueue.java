package multithread;

import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
class ProducerBQ implements Runnable
{
	private final BlockingQueue<Integer>  sharedQ;
	
	public ProducerBQ(BlockingQueue<Integer>  sharedQ)
	{
		this.sharedQ = sharedQ;
	}
	
	@Override
	public void run(){
		
		while(true)
		{
			try
			{
				Random random = new Random(); 
				int number = random.nextInt(10);
				System.out.println("Producing value " + number);
				sharedQ.put(number);
			}
			catch(InterruptedException ie)
			{
				System.err.println("Error :: " + ie);
			}
		}
	}
}
class ConsumerBQ implements Runnable
{
	private final BlockingQueue<Integer>  sharedQ;
	
	public ConsumerBQ(BlockingQueue<Integer>  sharedQ)
	{
		this.sharedQ = sharedQ;
	}
	
	@Override
	public void run(){
		
		while(true)
		{
			try
			{
				
				System.out.println("Consumed value " + sharedQ.take());
				
			}
			catch(InterruptedException ie)
			{
				System.err.println("Error :: " + ie);
			}
		}
	}
}

public class Blockingqueue {

	public static void main(String[] args) throws InterruptedException {
BlockingQueue<Integer> sharedQ = new LinkedBlockingQueue<Integer>(5);
		
		
		Thread consumerThread = new Thread(new ConsumerBQ(sharedQ));
		Thread producerThread = new Thread(new ProducerBQ(sharedQ) );
		
		producerThread.start();
		consumerThread.start();
		
		//producerThread.join();

	}

}
