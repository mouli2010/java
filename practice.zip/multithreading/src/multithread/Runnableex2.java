package multithread;

public class Runnableex2 {

	public static void main(String[] args)throws Exception {
		Runnable obj1=() ->   
			{
			for(int i=1;i<=5;i++)
			{
				System.out.println("hii");
				try{Thread.sleep(500);
					}
				catch(Exception e) {
			}
			}
			}

		;
		Runnable obj2=new Runnable() {
			public void run()
			{
				for (int i = 1; i <=5; i++) 
				{
					System.out.println("helllo");
					try{
						Thread.sleep(500);
						}
					catch(Exception e) {
				                       }
				
			        }
			}
			
	
		};
		Thread t1=new Thread(obj1);
		Thread t2=new Thread(obj2);
		t1.start();
		try{
			Thread.sleep(50);
			}
		catch(Exception e) {
	                       }
		t1.setPriority(Thread.MIN_PRIORITY);
		t2.setPriority(Thread.MAX_PRIORITY);
		System.out.println(t1.getPriority());
		System.out.println(t2.getPriority());
		t1.setName("hi");
		t2.setName("hello");
		System.out.println(t1.getName());
		System.out.println(t2.getName());
		t2.start();
		System.out.println(t1.isAlive());
		t1.join();
		t2.join();
		System.out.println(t1.isAlive());
		System.out.println("bye");

	

	}

}
