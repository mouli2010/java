package multithread;
class Mythread extends Thread
{
	int[]values= {6,5,1,7,8};
	public void run()
	{
		for(int i=0;i<5;i++)
		{
			values[i]=values[i]*2;
			System.out.println(values[i]);
		}
	}
}
public class Mythreadapp {

	public static void main(String[] args) {
		Thread t1=new Mythread();
		t1.run(); 

	}

}
