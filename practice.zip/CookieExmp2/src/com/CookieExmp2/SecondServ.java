package com.CookieExmp2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SecondServ
 */
@WebServlet("/SecondServ")
public class SecondServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SecondServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		 res.setContentType("text/html");
	        PrintWriter pw = res.getWriter();
	        String exp = req.getParameter("first_exp");
	        String skills = req.getParameter("first_skills");
	        Cookie c4 = new Cookie("exp", exp);
	        Cookie c5 = new Cookie("skills", skills);
	        res.addCookie(c4);
	        res.addCookie(c5);
	        pw.println("<html><title>Second Servlet</title><body bgcolor=\"green\"><center>");
	        pw.println("<form	name=\"second\"	action=\"./test3\"	method=\"post\"><table bgcolor=\"lightblue\">");
	        pw.println("<tr><th>Enter  expected  salary  :  </th><td><input  type=\"text\"  name=\"second_sal\"value=\"\">");
	        pw.println("</td></tr><tr><th>Enter	preffered	location	:	</th><td><input	type=\"text\"name=\"second_loc\" value=\"\">");
	        pw.println("</td></tr><table><tr><td	align=\"center\"><input	type=\"submit\" name=\"second_submit\" value=\"Submit\">");
	        pw.println("</td></tr></table></table></form></center></body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
