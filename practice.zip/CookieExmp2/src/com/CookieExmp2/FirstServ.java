package com.CookieExmp2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServ
 */
@WebServlet("/FirstServ")
public class FirstServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FirstServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		res.setContentType("text/html");
        PrintWriter pw = res.getWriter();
        String name = req.getParameter("ex_name");
        String address = req.getParameter("ex_add");
        String age = req.getParameter("ex_age");
        Cookie c1 = new Cookie("name", name);
        Cookie c2 = new Cookie("address", address);
        Cookie c3 = new Cookie("age", age);
        res.addCookie(c1);
        res.addCookie(c2);
        res.addCookie(c3);
        pw.println("<html><title>First Servlet</title><body bgcolor=\"green\"><center>");
        pw.println("<form name=\"first\" action=\"./test2\" method=\"post\"><table bgcolor=\"lightblue\">");
        pw.println("<tr><th>Enter   ur   experience   :   </th><td><input   type=\"text\"   name=\"first_exp\"value=\"\">");
        pw.println("</td></tr><tr><th>Enter  ur  skills  :  </th><td><input  type=\"text\"  name=\"first_skills\" value=\"\">");
        pw.println("</td></tr><table><tr><td  align=\"center\"><input type=\"submit\" name=\"first_submit\"value=\"Continue\">");
        pw.println("</td></tr></table></table></form></center></body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
