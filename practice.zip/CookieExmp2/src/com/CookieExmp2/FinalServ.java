package com.CookieExmp2;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FinalServ
 */
@WebServlet("/FinalServ")
public class FinalServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FinalServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		ArrayList al = new ArrayList();
        res.setContentType("text/html");
        PrintWriter pw = res.getWriter();
        String sal = req.getParameter("second_sal");
        String location = req.getParameter("second_loc");
        Cookie c6 = new Cookie("sal", sal);
        Cookie c7 = new Cookie("location", location);
        res.addCookie(c6);
        res.addCookie(c7);
        
        Cookie ck[] = req.getCookies();
        System.out.println(ck.length);
        for (int i = 0; i < ck.length; i++) {
            al.add(ck[i].getValue());
        }
        String name = al.get(0).toString();
        String address = al.get(1).toString();
        String age1 = al.get(2).toString();
    //  int age = Integer.parseInt(age1);
        String exp = al.get(3).toString();
    //  int experiance = Integer.parseInt(exp);
        String skills = al.get(4).toString();
        String sal1=al.get(5).toString();
       // float salary = Float.parseFloat(sal1);
        String loca=al.get(6).toString();
        
        System.out.println(name+""+address+""+age1+""+exp+""+skills+""+sal1+""+loca);
        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/rajamouli", "postgres", "mouli123");
            PreparedStatement ps = con.prepareStatement("INSERT INTO studentdb.info VALUES(?, ?,?, ?, ?, ?,?);");
            ps.setString(1, name);
            ps.setString(2, address);
            ps.setString(3, age1);
            ps.setString(4, exp);
            ps.setString(5, skills);
            ps.setString(6, sal1);
            ps.setString(7, loca);
           // ps.executeUpdate();
            System.out.println(name+""+address+""+age1+""+exp+""+skills+""+sal1+""+loca);
            int j = ps.executeUpdate();
            System.out.println(j);
            if (j > 0) {
                pw.println("<html><body bgcolor=\"lightblue\"><center><h1><font color=\"red\"> Successfully ");
                pw.println("Inserted</font></h1></center><a  href=\"personal.html\">Home</a></body></html>");
            } else {
                pw.println("<html><body bgcolor=\"cyan\"><center><h1><font color=\"red\">Try Again");
                pw.println("</font></h1></center><a  href=\"personal.html\">Home</a></body></html>");
            }
        } catch (Exception e) {
            pw.println("<html><body bgcolor=\"cyan\"><center><h1><font color=\"red\">Try Again");
            pw.println("</font></h1></center><a href=\"personal.html\">Home</a></body></html>");
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
