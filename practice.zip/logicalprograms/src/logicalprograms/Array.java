package logicalprograms;

public class Array {

	public static void main(String[] args) {
		int arr[]={1,2,3,4};
		/*int arr1[]=new int[4];
		for(int i=0, j=arr.length-1;i<arr.length;i++,j--)
		{
			arr1[i]=arr[j];
			System.out.print(arr1[i]); 
		}
		*/
		/*for (int i =arr.length-1;i>=0 ;i--) {
			System.out.print(arr[i]);
			
		}*/
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+","+arr[i]+",");
		}
		

	}

}
