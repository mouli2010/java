import java.io.FileInputStream;
import java.io.FileOutputStream;
public class Imagecopy {

	public static void main(String[] args) throws Exception{
		try{
		FileInputStream fio=new FileInputStream("E:/20kb.jpg");
		int size=fio.available();
		byte [] b=new byte[size];
		fio.read(b);
		FileOutputStream fout=new FileOutputStream("E:/mouliimage.jpg");
		fout.write(b);
		fio.close();
		fout.close();
		
		}
		catch(Exception E)
		{
			
		}   
	}

}
