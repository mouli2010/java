import java.io.FileInputStream;
public class FisExample {

	public static void main(String[] args) throws Exception {
		try{
		FileInputStream fio=new FileInputStream("E:/out.txt");
		int size=fio.available();
		byte [] b=new byte[size];
		fio.read(b);
		String data=new String(b);
		System.out.println(data);
	fio.close();
		}
		catch(Exception E)
		{
			
		}
	}

}