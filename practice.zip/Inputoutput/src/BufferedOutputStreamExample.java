import java.io.*;
public class BufferedOutputStreamExample {

	public static void main(String[] args) {
		try{
		FileOutputStream fout=new FileOutputStream("E:/testout.txt");
		BufferedOutputStream bout=new BufferedOutputStream(fout);
		String str="welcome to javatpoint";
		byte b[]=str.getBytes();
		bout.write(b);
		bout.flush();
		bout.close();
		fout.close();
		System.out.println("success");
		}
		catch(Exception E)
		{
			
		}
	}

}
