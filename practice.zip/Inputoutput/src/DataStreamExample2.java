import java.io.FileInputStream;
public class DataStreamExample2 {

	public static void main(String[] args) {
		try{
		FileInputStream fio=new FileInputStream("E:/out.txt");
		int i=0;
		while((i=fio.read())!=-1)
		{
			System.out.print((char)i);
			
		}
	
		}
		catch(Exception E)
		{
			
		}
	}

}
