import java.io.FileOutputStream;
public class FileOutputStreamExample {

	public static void main(String[] args) {
		String str="hello";
	try{
		
		FileOutputStream fout=new FileOutputStream("E:/out.txt");
		fout.write(str.getBytes());
		fout.close();
		System.out.println("done");
	}
catch(Exception E)
	{
	
	}
	
	}

}
