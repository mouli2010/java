import java.io.IOException;
import java.nio.file.*;


public class Copyfile {

	public static void main(String[] args) {
		String source= "E:\\HelloWorld.pdf";
		String destination="E:\\WorldHello.pdf";
		Path src=Paths.get(source);
		Path dest = Paths.get(destination);
		try {
			Files.copy(src, dest);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
