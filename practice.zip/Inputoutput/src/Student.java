import java.io.Serializable;
//import java.io.*;
public class Student  implements Serializable{
	
		int id;  
		transient  String name;  
		 public Student(int id, String name) {  
		  this.id = id;  
		  this.name = name;  
		 }
	}


