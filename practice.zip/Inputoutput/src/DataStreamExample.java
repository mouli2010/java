import java.io.FileInputStream;
public class DataStreamExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			FileInputStream fio=new FileInputStream("E:/out.txt");
			int i=fio.read();
			System.out.println((char)i);
			fio.close();
			System.out.println("sucessfull");
		}
		catch(Exception E)
		{
			
		}

	}

}
