import java.io.*;
 class Deserialize {

	public static void main(String[] args) throws Exception{
		ObjectInputStream in=new ObjectInputStream(new FileInputStream("E:\\raja.txt"));  
		  Student s=(Student)in.readObject();  
		  System.out.println(s.id+" "+s.name);  
		  
		  in.close();    
	}

}
