import java.io.FileReader;
public class FileReaderExample {

	public static void main(String[] args) {
		try{
			FileReader fr=new FileReader("e:\\mouli.txt");
			int i=0;
			while((i=fr.read())!=-1)
			{
				System.out.print((char)i);
			}
			fr.close();
			System.out.println("done");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

	}

}
